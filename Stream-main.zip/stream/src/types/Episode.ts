export default interface Episode {
  number: number;
  title: string;
  description: string;
  image: string;
  runtime: number;
}
