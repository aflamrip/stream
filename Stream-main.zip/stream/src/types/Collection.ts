import MediaShort from './MediaShort';

export default interface Collection {
  title: string;
  items: MediaShort[];
}
