type MediaType = 'movie' | 'series';

export default MediaType;
