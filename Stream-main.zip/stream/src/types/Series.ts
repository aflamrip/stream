import Media from './Media';

export default interface Series extends Media {
  seasons: number;
}
