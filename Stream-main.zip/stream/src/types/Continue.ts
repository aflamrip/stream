export default interface Continue {
  season: number;
  episode: number;
}
